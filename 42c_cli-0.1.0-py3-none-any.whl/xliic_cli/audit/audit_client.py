import base64
import logging
import time
from typing import Collection, List, Literal
import json
from ruamel.yaml.comments import CommentedMap
from datetime import datetime
from typing import Any

from requests import HTTPError, RequestException, Response
import requests
from xliic_cli.helpers.errors import TaskError

from xliic_cli.audit.models import (
    Api,
    ApiReport,
    ApiStatus,
    ApiResponse,
    BlockingGate,
    NamingConvention,
    PlatformConfig,
    RemoteApiError,
    SecurityGates,
    Tag,
    TagsCategory,
    TaskOptions,
)
from xliic_cli.helpers.constants import ASSESSMENT_MAX_WAIT, ASSESSMENT_RETRY


class AuditClient:
    def __init__(self, task_options: TaskOptions):
        self.task_options = task_options
        self.headers = _get_headers(
            task_options.api_token,
            task_options.user_agent,
            task_options.referer,
        )

    def get_list_api(self, collection_id: str) -> list[ApiResponse] | RemoteApiError:
        path = f"api/v1/collections/{collection_id}/apis"
        response = _send("get", path, self.task_options, self.headers)

        if isinstance(response, Response):
            return response.json()["list"]
        return response

    def get_list_collections_id(self) -> list[str] | RemoteApiError:
        path = "api/v1/collections"
        response = _send("get", path, self.task_options, self.headers)
        if isinstance(response, Response):
            return [obj["desc"]["id"] for obj in response.json()["list"]]
        return response

    def delete_api(self, api_id: str) -> str | RemoteApiError:
        path = f"api/v1/apis/{api_id}"
        response = _send("delete", path, self.task_options, self.headers)
        if isinstance(response, Response):
            return response.json()["id"]
        return response

    def create_technical_api(self, collection_id: str, filename: str, name: str, api: CommentedMap) -> Api | RemoteApiError:
        path = "api/v2/apis"
        data = {
            "cid": collection_id,
            "name": name,
            "technicalName": filename,
            "specfile": _to_base64(api),
        }
        response = _send("post", path, self.task_options, self.headers, data=data)
        if isinstance(response, Response):
            returned_api: Api = Api(response.json()["desc"]["id"], "created", ApiStatus())

            if len(self.task_options.api_tags) > 0:
                self.read_assessment(returned_api)
                self.assign_set_tag(returned_api.id, self.task_options.api_tags)
                new_status = self.read_api_status(returned_api.id)
                if isinstance(new_status, RemoteApiError):
                    return new_status
                else:
                    returned_api.previous_status = new_status
                    time.sleep(1)
                    # self.request_audit(api['id'])
            return returned_api
        return response

    def read_api_status(self, api_id: str) -> ApiStatus | RemoteApiError:
        path = f"api/v1/apis/{api_id}"
        response = _send("get", path, self.task_options, self.headers)
        if isinstance(response, Response):
            last_assessment = (
                datetime.fromisoformat(response.json()["assessment"]["last"])
                if response.json()["assessment"] and response.json()["assessment"].get("last")
                else datetime.utcfromtimestamp(0)
                if response.json().get("assessment") and not response.json()["assessment"].get("last")
                else datetime.utcfromtimestamp(0)
            )
            is_assessment_processed = response.json()["assessment"]["isProcessed"] or False
            last_scan = (
                datetime.fromisoformat(response.json()["scan"]["last"])
                if response.json().get("scan") and response.json()["scan"].get("last")
                else datetime.utcfromtimestamp(0)
                if response.json().get("scan") and response.json()["scan"].get("last")
                else datetime.utcfromtimestamp(0)
            )
            is_scan_processed = response.json()["scan"]["isProcessed"] or False
            return ApiStatus(
                is_assessment_processed,
                last_assessment,
                is_scan_processed,
                last_scan,
                [Tag(tag["categoryName"], tag["tagName"]) for tag in response.json()["tags"]],
            )
        return response

    def update_api(self, api_id: str, api: CommentedMap) -> Api | RemoteApiError:
        path = f"api/v1/apis/{api_id}"

        data = {"specfile": _to_base64(api)}

        previous_status = self.read_api_status(api_id)
        if isinstance(previous_status, RemoteApiError):
            return previous_status
        else:
            response = _send("put", path, self.task_options, self.headers, data=data)
            if isinstance(response, Response):
                return Api(response.json()["desc"]["id"], "updated", previous_status)
            return response

    def read_collection(self, collection_id: str) -> Collection | RemoteApiError:
        path = f"api/v1/collections/{collection_id}"
        response = _send("get", path, self.task_options, self.headers)
        if isinstance(response, Response):
            return response.json()
        return response

    def delete_collection(self, collection_id: str) -> str | RemoteApiError:
        path = f"api/v1/collections/{collection_id}"
        response = _send("delete", path, self.task_options, self.headers)
        if isinstance(response, Response):
            return response.json()["id"]
        return response

    def create_collection(self, technical_name: str, name: str) -> Collection | RemoteApiError:
        path = "api/v1/collections/technicalName"
        data = {
            "technicalName": technical_name,
            "name": name,
            "source": self.task_options.cicd_name,
            "isShared": self.task_options.share_everyone or self.task_options.share_teams_read_write,
            "isSharedWrite": self.task_options.share_teams_read_write,
        }
        response = _send("post", path, self.task_options, self.headers, data=data)
        if isinstance(response, Response):
            return response.json()
        return response

    def read_assessment(self, api: Api) -> ApiReport | RemoteApiError:
        self.task_options.logger.debug(f"Reading assessment report for API ID: {api.id}")
        path = f"api/v1/apis/{api.id}/assessmentreport"
        start = datetime.utcfromtimestamp(0)
        now = datetime.now()
        while now.timestamp() - start.timestamp() < ASSESSMENT_MAX_WAIT * 1000:
            status = self.read_api_status(api.id)
            if isinstance(status, RemoteApiError):
                return status
            else:
                ready = status.is_assessment_processed and status.last_assessment > api.previous_status.last_assessment
                if ready:
                    response = _send("get", path, self.task_options, self.headers)
                    if isinstance(response, Response):
                        body = response.json()
                        report = json.loads(base64.b64decode(body["data"]).decode("utf-8"))
                        return ApiReport(body["tid"], report)
                    else:
                        return response

                self.task_options.logger.debug(f"Assessment report for API ID: {api.id} is not ready, retrying.")
                time.sleep(ASSESSMENT_RETRY)
                now = datetime.now()

        raise TaskError(f"Timed out while waiting for the assessment report for API ID: {api.id}")

    def read_compliance(self, task_id: str) -> List[BlockingGate] | RemoteApiError:
        path = f"api/v2/sqgs/audit/reportComplianceStatus/{task_id}"
        response = _send("get", path, self.task_options, self.headers)
        if isinstance(response, Response):
            return [BlockingGate(sqg["blockingSqgId"], sqg["blockingRules"]) for sqg in response.json()["processingDetails"]]
        return response

    def read_gates(self) -> SecurityGates | RemoteApiError:
        path = "api/v2/sqgs/audit"
        response = _send("get", path, self.task_options, self.headers)
        if isinstance(response, Response):
            gates = response.json().get("list", [])
            if gates:
                sequrity_gates: SecurityGates = {}
                for gate in response.json()["processingDetails"]:
                    sequrity_gates[gate["id"]] = {"name": gate["name"]}
                return sequrity_gates
            return {}
        return response

    def get_api_naming_convention(self) -> NamingConvention | RemoteApiError:
        path = "api/v1/organizations/me/settings/apiNamingConvention"
        response = _send("get", path, self.task_options, self.headers)

        if isinstance(response, Response):
            return response.json()
        return response

    def get_collection_naming_convention(self) -> NamingConvention | RemoteApiError:
        path = "api/v1/organizations/me/settings/collectionNamingConvention"
        response = _send("get", path, self.task_options, self.headers)

        if isinstance(response, Response):
            return response.json()
        return response

    def get_platform_tags(self) -> List[Tag] | RemoteApiError:
        path = "api/v2/tags"
        response = _send("get", path, self.task_options, self.headers)

        if isinstance(response, Response):
            return [Tag(tag["categoryName"], tag["tagName"]) for tag in response.json()["list"]]
        return response

    def get_platform_tags_categories(self) -> List[TagsCategory] | RemoteApiError:
        path = "api/v2/categories"
        response = _send("get", path, self.task_options, self.headers)

        if isinstance(response, Response):
            return [
                TagsCategory(
                    category["name"],
                    category["description"],
                    category["color"],
                    category["isFreeForm"],
                    category["isExclusive"],
                    category["onlyAdminCanTag"],
                )
                for category in response.json()["list"]
            ]
        return response

    def assign_set_tag(self, api_id: str, tags: List[Tag]):
        path = f"api/v2/apis/{api_id}/tags/assignset"
        data: Any = {"list": [{"categoryName": tag.category_name, "tagName": tag.tag_name} for tag in tags]}
        response = _send("put", path, self.task_options, self.headers, data=data)

        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't assign tags for {api_id}: {response}")
            raise TaskError(f"Can't assign tags for {api_id}: {response}")

    def save_tag(self, tag: Tag):
        path = f"api/v2/categories/{tag.category_name}/tags"
        data: Any = {
            "name": tag.tag_name,
        }
        response = _send("post", path, self.task_options, self.headers, data=data)

        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't save tag {tag}: {response}")
            raise TaskError(f"Can't save tag {tag}: {response}")

    def save_tag_category(self, category: TagsCategory):
        path = "api/v2/categories"
        data: Any = {
            "name": category.name,
            "color": category.color,
            "isFreeForm": category.is_free_form,
            "isExclusive": category.is_exclusive,
            "onlyAdminCanTag": category.only_admin_can_tag,
            "description": category.description,
        }
        response = _send("post", path, self.task_options, self.headers, data=data)

        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't save categoty {category}: {response}")
            raise TaskError(f"Can't save category {category}: {response}")

    def update_tag_category(self, category: TagsCategory) -> str:
        path = f"api/v2/categories/{category.name}"
        data: Any = {
            "name": category.name,
            "color": category.color,
            "isFreeForm": category.is_free_form,
            "isExclusive": category.is_exclusive,
            "onlyAdminCanTag": category.only_admin_can_tag,
            "description": category.description,
        }
        response = _send("put", path, self.task_options, self.headers, data=data)

        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't update categoty {category}: {response}")
            raise TaskError(f"Can't update category {category}: {response}")
        return response.json()["id"]

    def delete_tag(self, tag: Tag):
        path = f"api/v2/categories/{tag.category_name}/tags/{tag.tag_name}"
        response = _send("delete", path, self.task_options, self.headers)
        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't delete tag {tag}: {response}")
            raise TaskError(f"Can't delete tag {tag}: {response}")

    def delete_tag_category(self, category_name: str):
        path = f"api/v2/categories/{category_name}"
        response = _send("delete", path, self.task_options, self.headers)
        if not isinstance(response, Response):
            self.task_options.logger.error(f"Can't delete tag category {category_name}: {response}")
            raise TaskError(f"Can't delete tag category {category_name}: {response}")

    def get_platform_config(self) -> PlatformConfig | RemoteApiError:
        gates = self.read_gates()
        if isinstance(gates, RemoteApiError):
            return gates
        api_naming_convention = self.get_api_naming_convention()
        if isinstance(api_naming_convention, RemoteApiError):
            return api_naming_convention
        collection_naming_convention = self.get_collection_naming_convention()
        if isinstance(collection_naming_convention, RemoteApiError):
            return collection_naming_convention
        return PlatformConfig(api_naming_convention, collection_naming_convention, gates)


def _get_headers(api_key, user_agent, referer):
    return {
        "Accept": "application/json",
        "X-API-KEY": api_key,
        "User-Agent": user_agent,
        "Referer": referer,
    }


def _send(
    method: Literal["get", "post", "put", "delete"],
    path: str,
    options: TaskOptions,
    headers,
    data=None,
) -> Response | RemoteApiError:
    try:
        url = f"{options.platform_url}/{path}"
        response = getattr(requests, method)(url, headers=headers, json=data)
        response.raise_for_status()
        return response
    except RequestException as e:
        res = _handle_http_error(e, options.platform_url, options.logger)
        if isinstance(res, Exception):
            raise res
        else:
            return res


def _handle_http_error(err: Any, platform_url: str, logger: logging.Logger) -> RemoteApiError:
    if isinstance(err, HTTPError):
        if err.response.status_code == 409 and err.response.json().get("message") == "limit reached":
            return RemoteApiError(
                err.response.status_code,
                err.response.text,
                f"You have reached your maximum number of APIs. Please sign into {platform_url} and upgrade your account.",
                err.response.headers.get("x-42c-transactionid"),
            )
        elif (
            err.response.status_code == 404
            and err.response.json().get("message") == "no result"
            and err.response.json().get("code") == 5
        ):
            return RemoteApiError(
                err.response.status_code,
                err.response.text,
                "Object does not exist, check that ID or name of your object is correct",
                err.response.headers.get("x-42c-transactionid"),
            )
        else:
            return RemoteApiError(
                err.response.status_code,
                err.response.text,
                f"Error occurred during the request {err.request.method} {err.request.url}",
                err.response.headers.get("x-42c-transactionid"),
            )
    raise err


def _to_base64(api: CommentedMap):
    return base64.standard_b64encode(json.dumps(api).encode()).decode()
