from dataclasses import dataclass, field
from enum import Enum
import logging
from datetime import datetime
from typing import Any, Literal, Optional, List, Dict, Union


class SharingType(Enum):
    ReadOnly = 1
    ReadWrite = 2


class Severity(Enum):
    critical = 1
    high = 2
    medium = 3
    low = 4
    info = 5


@dataclass
class Reference:
    branch: Optional[str]
    tag: Optional[str]
    pr: Optional[Dict[str, str]]


@dataclass
class SeverityPerCategory:
    data: Optional[Severity]
    security: Optional[Severity]


@dataclass
class Score:
    data: Optional[int]
    security: Optional[int]
    overall: Optional[int]


@dataclass
class Discovery:
    name: Optional[str]
    search: List[str]


@dataclass
class FailureConditions:
    invalid_contract: bool
    issue_id: List[str]
    severity: Optional[Union[SeverityPerCategory, Severity]]
    score: Optional[Score]


@dataclass
class TaskConfig:
    discovery: Optional[Discovery]
    api_tags: List[str]
    mapped_files: Optional[Dict[str, str]]


@dataclass
class AuditConfig(TaskConfig):
    failureConditions: FailureConditions


@dataclass
class Tag:
    tag_name: str
    category_name: str


@dataclass
class TaskOptions:
    referer: str
    user_agent: str
    api_token: str
    onboarding_url: str
    platform_url: str
    logger: logging.Logger
    reference: Reference
    repo_name: str
    cicd_name: str
    root_dir: str
    config: TaskConfig
    api_tags: List[Tag]
    share_everyone: Optional[SharingType]
    share_teams_read_only: Optional[List[str]] = None
    share_teams_read_write: Optional[List[str]] = None


@dataclass
class RemoteApiError:
    statusCode: int
    error: Any
    description: str
    transactionId: str


@dataclass
class ApiErrors:
    convention: Optional[str]
    parsing: Optional[str]
    bundling: Optional[str]
    remote: Optional[RemoteApiError]


@dataclass
class BaseDescription:
    id: str
    technicalName: str


@dataclass
class ApiResponse:
    desc: BaseDescription


@dataclass
class Collection:
    desc: BaseDescription


@dataclass
class ApiStatus:
    is_assessment_processed: bool = False
    last_assessment: datetime = datetime.utcfromtimestamp(0)
    is_scan_processed: bool = False
    last_scan: datetime = datetime.utcfromtimestamp(0)
    tags: List[Tag] = field(default_factory=list)


@dataclass
class JsonMapping:
    file: str
    hash: str


@dataclass
class MappingTreeNode:
    value: Optional[JsonMapping]
    children: Dict[str, "MappingTreeNode"]


@dataclass
class Api:
    id: str
    lifecycle: Literal["created", "updated"]
    previous_status: ApiStatus
    mapping: Optional[MappingTreeNode] = None


@dataclass
class ApiReport:
    tid: str
    data: Any


@dataclass
class BlockingGate:
    blocking_sqg_id: str
    blocking_rules: str


SecurityGates = Dict[str, Dict[str, str]]


@dataclass
class NamingConvention:
    pattern: str
    description: str
    example: str


@dataclass
class TagsCategory:
    name: str
    description: Optional[str] = ""
    color: Optional[str] = "#FFFFFF"
    is_free_form: Optional[bool] = True
    is_exclusive: Optional[bool] = False
    only_admin_can_tag: Optional[bool] = False


@dataclass
class PlatformConfig:
    api_naming_convention: NamingConvention
    collectionNamingConvention: NamingConvention
    gates: Optional[SecurityGates] = None


@dataclass
class AuditInputs:
    min_score: Optional[str]
    line_numbers: Optional[str]
    default_collection_name: Optional[str]
    write_json_report_to: Optional[str]
    skip_local_checks: Optional[bool]
    referer: str
    user_agent: str
    api_token: str
    onboarding_url: str
    platform_url: str
    logger: logging.Logger
    reference: Reference
    repo_name: str
    cicd_name: str
    root_dir: str
    share_everyone: Optional[SharingType]
    share_teams_read_only: Optional[List[str]]
    share_teams_read_write: Optional[List[str]]
    api_tags: Optional[str]


@dataclass
class YamlDiscovery:
    search: List[str]
    collection_name: str


@dataclass
class YamlFailureConditions:
    invalid_contract: Optional[bool]
    issue_id: Optional[List[str]]
    severity: Optional[Union[SeverityPerCategory, Severity]]
    score: Optional[Union[Score, int]]


Mapping = Dict[str, str]
FileApiIdMap = Dict[str, str]


@dataclass
class YamlTaskConfig:
    fail_on: Optional[YamlFailureConditions]
    mapping: Optional[Mapping]
    discovery: Optional[Union[YamlDiscovery, bool]]
    api_tags: List[str]
